/********************************************************************************************************
 * QRNA - Comparative analysis of biological sequences 
 *         with pair hidden Markov models, pair stochastic context-free
 *        grammars, and probabilistic evolutionary  models.
 *       
 * Copyright (C) 2000-2006 Howard Hughes Medical Institute/Washington University School of Medicine
 * All Rights Reserved
 * 
 *     This source code is distributed under the terms of the
 *     GNU General Public License. See the files COPYING and LICENSE
 *     for details.
 ***********************************************************************************************************/


/* version.h
 * 
 */

#define PACKAGE     "QRNA"
#define RELEASE     "2.0.3d"
#define RELEASEDATE "Sun Feb 19 2006"
#define COPYRIGHT   "Copyright (C) 2000-2006 Howard Hughes Medical Institute/Washington University School of Medicine"
#define LICENSE     "Freely distributed under the GNU General Public License (GPL)"

